public class Camion extends Vehicule implements Louable {
    private double capaciteChargement; // en tonnes
    private int nombreEssieux;

    public Camion(String immatriculation, String marque, String modele, int anneeMiseEnService, double kilometrage, double capaciteChargement, int nombreEssieux) {
        super(immatriculation, marque, modele, anneeMiseEnService, kilometrage);
        this.capaciteChargement = capaciteChargement;
        this.nombreEssieux = nombreEssieux;
    }

    @Override
    public double calculerPrixLocation(int duree) {
        return 100.0 * duree; 
    }

    @Override
    public void louer() throws VehiculeIndisponibleException {
        if (!this.isLouee()) { 
            this.setLouee(true); 
            System.out.println("Le camion a été loué.");
        } else throw new VehiculeIndisponibleException("Ce camion est déjà en location");
    }

    @Override
    public void retourner() {
        if (this.isLouee()) { 
            this.setLouee(false); 
            System.out.println("Le camion a été retourné.");
        } else {
            System.out.println("Le camion n'était pas loué.");
        }
    }

    public double getCapaciteChargement() {
        return capaciteChargement;
    }

    public void setCapaciteChargement(double capaciteChargement) {
        this.capaciteChargement = capaciteChargement;
    }

    public int getNombreEssieux() {
        return nombreEssieux;
    }

    public void setNombreEssieux(int nombreEssieux) {
        this.nombreEssieux = nombreEssieux;
    }
}
