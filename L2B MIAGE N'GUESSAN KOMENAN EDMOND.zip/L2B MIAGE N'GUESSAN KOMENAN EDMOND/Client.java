import java.util.ArrayList;
import java.util.List;

public class Client {
    private String nom;
    private String prenom;
    private String numeroPermis;
    private String telephone;
    private List<Vehicule> locationsEnCours;

    public Client(String nom, String prenom, String numeroPermis, String telephone) {
        this.nom = nom;
        this.prenom = prenom;
        this.numeroPermis = numeroPermis;
        this.telephone = telephone;
        this.locationsEnCours = new ArrayList<>();
    }

    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public String getNumeroPermis() { return numeroPermis; }
    public String getTelephone() { return telephone; }
    public List<Vehicule> getLocationsEnCours() { return locationsEnCours; }

    public void ajouterLocation(Vehicule vehicule) {
        locationsEnCours.add(vehicule);
    }

    public void retirerLocation(Vehicule vehicule) {
        locationsEnCours.remove(vehicule);
    }
}
