public interface Louable {
    void louer() throws VehiculeIndisponibleException;
    void retourner();
}
