import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        ParcAutomobile parc = new ParcAutomobile();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu :");
            System.out.println("1. Ajouter un nouveau véhicule");
            System.out.println("2. Ajouter un nouveau client");
            System.out.println("3. Louer un véhicule à un client");
            System.out.println("4.Retourner un véhicule");
            System.out.println("5. Lister les véhicules disponibles");
            System.out.println("6. Lister les véhicules loués");
            System.out.println("0. Quitter");
            System.out.print("Choix : ");
            int choix = scanner.nextInt();
            scanner.nextLine(); 

            switch (choix) {
                case 1:


                    ajouterVehicule(parc, scanner);
                    break;
                case 2:
                    ajouterClient(parc, scanner);
                    break;
                case 3:
                    louerVehicule(parc, scanner);
                    break;
                case 4:
                    retournerVehicule(parc, scanner);
                    break;
                case 5:
                    parc.afficherVehiculesDisponibles();
                    break;
                case 6:
                    parc.afficherVehiculesLoues();
                    break;
                case 7:
                    System.out.println("Au revoir !");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Sélection non valide, veuillez réessayer.");
            }
        }
    }

    public static void ajouterVehicule(ParcAutomobile parc, Scanner scanner) {
        System.out.print("Entrez le type de véhicule (voiture/camion) : ");
        String type = scanner.nextLine();
        System.out.print("Immatriculation : ");
        String immatriculation = scanner.nextLine();
        System.out.print("Marque : ");
        String marque = scanner.nextLine();
        System.out.print("Modèle : ");
        String modele = scanner.nextLine();
        System.out.print("Année de mise en service : ");
        int annee = scanner.nextInt();
        System.out.print("Kilométrage : ");
        double kilometrage = scanner.nextDouble();
        scanner.nextLine(); 

        if (type.equalsIgnoreCase("voiture")) {
            System.out.print("Nombre de places : ");
            int places = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Type de carburant (essence/diesel/électrique) : ");
            String carburant = scanner.nextLine();
            Voiture voiture = new Voiture(immatriculation, marque, modele, annee, kilometrage, places, carburant);
            parc.ajouterVehicule(voiture);
        } else if (type.equalsIgnoreCase("camion")) {
            System.out.print("Capacité de chargement (en tonnes) : ");
            double capacite = scanner.nextDouble();
            System.out.print("Nombre d'essieux : ");
            int essieux = scanner.nextInt();
            Camion camion = new Camion(immatriculation, marque, modele, annee, kilometrage, capacite, essieux);
            parc.ajouterVehicule(camion);
        } else {
            System.out.println("Type de véhicule inconnu.");
        }
    }

    public static void ajouterClient(ParcAutomobile parc, Scanner scanner) {
        System.out.print("Nom : ");
        String nom = scanner.nextLine();
        System.out.print("Prénom : ");
        String prenom = scanner.nextLine();
        System.out.print("Numéro de permis : ");
        String numeroPermis = scanner.nextLine();
        System.out.print("Numéro de téléphone : ");
        String telephone = scanner.nextLine();
        Client client = new Client(nom, prenom, numeroPermis, telephone);
        parc.ajouterClient(client);
    }

    public static void louerVehicule(ParcAutomobile parc, Scanner scanner) {
        System.out.print("Entrez le numéro de permis du client : ");
        String numeroPermis = scanner.nextLine();
        Client client = parc.rechercherClient(numeroPermis);
        if (client == null) {
            System.out.println("Client introuvable.");
            return;
        }

        System.out.print("Entrez l'immatriculation du véhicule à louer : ");
        String immatriculation = scanner.nextLine();
        Vehicule vehicule = parc.rechercherVehicule(immatriculation);
        if (vehicule == null) {
            System.out.println("Véhicule introuvable.");
            return;
        }

        try {
            if (vehicule instanceof Louable) {
                ((Louable) vehicule).louer();
                client.ajouterLocation(vehicule);
            } else {
                System.out.println("Impossible de louer ce vehicule.");
            }
        } catch (VehiculeIndisponibleException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void retournerVehicule(ParcAutomobile parc, Scanner scanner) {
        System.out.print("Veuillez entrer le numero d'immatriculation du vehicule");
        String immatriculation = scanner.nextLine();
        Vehicule vehicule = parc.rechercherVehicule(immatriculation);
        if (vehicule == null) {
            System.out.println("Véhicule introuvable.");
            return;
        }

        try {
            if (vehicule instanceof Louable) {
                ((Louable) vehicule).retourner();
                
            } else {
                System.out.println("Impossible de retourner ce vehicule.");
            }
        } catch (Exception e) {
            System.out.println("Erreur lors du retour du véhicule : " + e.getMessage());
        }
    }
}
