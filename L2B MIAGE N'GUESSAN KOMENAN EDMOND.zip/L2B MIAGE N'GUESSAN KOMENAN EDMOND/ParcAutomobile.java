import java.util.ArrayList;
import java.util.List;

public class ParcAutomobile {
    private List<Vehicule> vehicules;
    private List<Client> clients;

    public ParcAutomobile() {
        this.vehicules = new ArrayList<>();
        this.clients = new ArrayList<>();
    }

    // Méthodes pour gérer les véhicules
    public void ajouterVehicule(Vehicule vehicule) {
        vehicules.add(vehicule);
        System.out.println("Véhicule ajouté au parc : " + vehicule.getImmatriculation());
    }

    public List<Vehicule> getVehiculesDisponibles() {
        List<Vehicule> disponibles = new ArrayList<>();
        for (Vehicule vehicule : vehicules) {
            if (!vehicule.isLouee()) {
                disponibles.add(vehicule);
            }
        }
        return disponibles;
    }

    public Vehicule rechercherVehicule(String immatriculation) {
        for (Vehicule vehicule : vehicules) {
            if (vehicule.getImmatriculation().equalsIgnoreCase(immatriculation)) {
                return vehicule;
            }
        }
        return null;
    }

    // Méthodes pour gérer les clients
    public void ajouterClient(Client client) {
        clients.add(client);
        System.out.println("Client ajouté : " + client.getNom() + " " + client.getPrenom());
    }

    public Client rechercherClient(String numeroPermis) {
        for (Client client : clients) {
            if (client.getNumeroPermis().equalsIgnoreCase(numeroPermis)) {
                return client;
            }
        }
        return null;
    }

    // Méthode pour lister les véhicules disponibles ou loués
    public void afficherVehiculesDisponibles() {
        List<Vehicule> disponibles = getVehiculesDisponibles();
        if (disponibles.isEmpty()) {
            System.out.println("Aucun véhicule disponible.");
        } else {
            System.out.println("Véhicules disponibles :");
            for (Vehicule vehicule : disponibles) {
                System.out.println(vehicule.getMarque() + " " + vehicule.getModele() + " (Immatriculation : " + vehicule.getImmatriculation() + ")");
            }
        }
    }

    public void afficherVehiculesLoues() {
        boolean hasLoues = false;
        System.out.println("Véhicules loués :");
        for (Vehicule vehicule : vehicules) {
            if (vehicule.isLouee()) {
                hasLoues = true;
                System.out.println(vehicule.getMarque() + " " + vehicule.getModele() + " (Immatriculation : " + vehicule.getImmatriculation() + ")");
            }
        }
        if (!hasLoues) {
            System.out.println("Aucun véhicule n'est actuellement loué.");
        }
    }
}
