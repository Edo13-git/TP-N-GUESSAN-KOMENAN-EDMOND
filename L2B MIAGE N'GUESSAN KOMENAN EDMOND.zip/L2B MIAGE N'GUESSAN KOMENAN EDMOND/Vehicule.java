public abstract class Vehicule {
    private String immatriculation;
    private String marque;
    private String modele;
    private int anneeMiseEnService;
    private double kilometrage;
    private boolean estLouee;

    public Vehicule(String immatriculation, String marque, String modele, int anneeMiseEnService, double kilometrage) {
        this.immatriculation = immatriculation;
        this.marque = marque;
        this.modele = modele;
        this.anneeMiseEnService = anneeMiseEnService;
        this.kilometrage = kilometrage;
        this.estLouee = false; 
    }

    public String getImmatriculation() { return immatriculation; }
    public String getMarque() { return marque; }
    public String getModele() { return modele; }
    public int getAnneeMiseEnService() { return anneeMiseEnService; }
    public double getKilometrage() { return kilometrage; }
    public boolean isLouee() { return estLouee; }

    public void setLouee(boolean estLouee) { this.estLouee = estLouee; }

    
    public abstract double calculerPrixLocation(int duree);
}
