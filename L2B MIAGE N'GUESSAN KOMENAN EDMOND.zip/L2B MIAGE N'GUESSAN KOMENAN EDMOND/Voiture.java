public class Voiture extends Vehicule implements Louable {
    private int nombreDePlaces;
    private String typeCarburant; 

    public Voiture(String immatriculation, String marque, String modele, int anneeMiseEnService, double kilometrage, int nombreDePlaces, String typeCarburant) {
        super(immatriculation, marque, modele, anneeMiseEnService, kilometrage);
        this.nombreDePlaces = nombreDePlaces;
        this.typeCarburant = typeCarburant;
    }

    @Override
    public double calculerPrixLocation(int duree) {
        return 50.0 * duree; 
    }

    @Override
    public void louer() {
        if (!this.isLouee()) {
            this.setLouee(true);
            System.out.println("La voiture a été louée.");
        } else {
            try {
                throw new VehiculeIndisponibleException("Voiture déjà louée.");
            } catch (VehiculeIndisponibleException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    @Override
    public void retourner() {
        this.setLouee(false);
        System.out.println("La voiture a été retournée.");
    }
}
